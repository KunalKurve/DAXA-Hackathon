import { App } from "./src/app.js";

document.getElementById("root").innerHTML = `${App()}`;
